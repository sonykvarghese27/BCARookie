﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {
        DataTable dt = new DataTable();
        string strQuery = "select id, name from semsyllabus order by id";
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["bcarookieConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand(strQuery);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        if (Session["x"] == null)
        {
            Response.Write("<script LANGUAGE='JavaScript' >alert('Please login to use all features in this website')</script>");
            Response.Redirect("Login.aspx");
        }
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);

            gvDetails.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
            dt.Dispose();
        }
    }
   
    
}