﻿
Partial Class CAnswers
    Inherits System.Web.UI.Page

End Class
