﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void  Button1_Click1(object sender, EventArgs e)
{
    
        string connectionString = ConfigurationManager.ConnectionStrings["bcarookieConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        string strSelect = "SELECT COUNT(*) FROM Users WHERE  UserName= @UserName AND Password = @Password";
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = strSelect;
        SqlParameter username = new SqlParameter("@UserName", SqlDbType.VarChar, 50);
        username.Value = TextBox1.Text.Trim().ToString();
        cmd.Parameters.Add(username);
        SqlParameter pasword = new SqlParameter("@Password", SqlDbType.VarChar, 50);

        pasword.Value = TextBox2.Text.Trim().ToString();

        cmd.Parameters.Add(pasword);
        con.Open();
        int result = (Int32)cmd.ExecuteScalar();
        con.Close();
        if (result >= 1)
        {
            Session["x"] = TextBox1.Text;
            Session.Timeout=1;
           Response.Write("<script LANGUAGE='JavaScript' >alert('Welcome');document.location='" + ResolveClientUrl("~/home.aspx") + "';</script>");
            

        }

        else
            Response.Write("<script LANGUAGE='JavaScript' >alert('Incorrect Username or Password');document.location='" + ResolveClientUrl("~/Login.aspx") + "';</script>");
            
}
}
