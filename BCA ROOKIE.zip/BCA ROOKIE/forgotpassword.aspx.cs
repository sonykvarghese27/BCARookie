﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Mail;
using System.Net.Mail;

public partial class forgotpassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string str = "SELECT Email, Password, UserName FROM Users";
        string connectionString = ConfigurationManager.ConnectionStrings["bcarookieConnectionString"].ConnectionString;

        SqlConnection conn = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = conn;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = str;
        SqlDataReader reader;
        conn.Open();
        reader = cmd.ExecuteReader();

        while (reader.Read())
        {
            if (TextBox2.Text.Trim() == reader.GetString(0).Trim())
            {

                try
                {
                    System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage();
                    String Body = "Your password is" + reader.GetString(1).Trim() + "";
                    msg.From = new MailAddress("a.shreyas@gmail.com");
                    msg.To.Add(new MailAddress("sujays4@gmail.com"));
                    msg.Subject = "Password Recovery..!!";
                    msg.IsBodyHtml = true;
                    msg.Body = "Hello Mr./Mrs. " + reader.GetString(2).Trim() + " Your Password is.. "+ reader.GetString(1).Trim()  ;

                    SmtpClient objClient = new SmtpClient("smtp.gmail.com", 25);
                    objClient.EnableSsl = true;

                    // Here is your email id and password from where you have to send an email.
                    objClient.Credentials = new System.Net.NetworkCredential("a.shreyas92@gmail.com", "jrdshreyas");


                    objClient.Send(msg);
                    

                    Response.Write("Message sent");
                    Label4.Visible = true;
                    Label4.Text = "The password has been sent to your email_ID";

                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
            else
                Label4.Text = "The Email ID you have entered is wrong. Please try again";
        }



    }
}