﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;

public partial class AdminMaterial : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["bcarookieConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        string strQuery = "SELECT * FROM materials";
        SqlCommand cmd = new SqlCommand(strQuery);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        DataTable dt = new DataTable();
        con.Open();
        sda.SelectCommand = cmd;
        sda.Fill(dt);
        con.Close();
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        var ID = GridView1.DataKeys[e.RowIndex].Value;
        using (con)
        {
            string sql = "Delete from materials" +
                " where id = @ID";
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                cmd.Parameters.AddWithValue(
                      "@id", ID);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
    }

    private void BindGrid()
    {
        GridView1.DataSource = ViewState["dt"] as DataTable;
        GridView1.DataBind();
    }


    

    protected void Button1_Click(object sender, EventArgs e)
    {
        string filePath = FileUpload1.PostedFile.FileName;
        string filename = Path.GetFileName(filePath);
        string ext = Path.GetExtension(filename);
        string contenttype = String.Empty;
        if (FileUpload1.HasFile)
        {

            Stream fs = FileUpload1.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(fs);
            Byte[] bytes = br.ReadBytes((Int32)fs.Length);

            //insert the file into database
            string strQuery = "insert into materials(semester, subject, files)" +
               " values (@semester, @subject, @files)";
            SqlCommand cmd = new SqlCommand(strQuery);
            cmd.Parameters.Add("@semester", SqlDbType.VarChar).Value = DropDownList1.Text;
            cmd.Parameters.Add("@subject", SqlDbType.VarChar).Value = TextBox2.Text;
            cmd.Parameters.Add("@files", SqlDbType.VarBinary).Value = bytes;
            InsertUpdateData(cmd);
            BindGrid();
            TextBox2.Text = "";
        }
    }
    private Boolean InsertUpdateData(SqlCommand cmd)
    {
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            return true;
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            return false;
        }
        finally
        {
            con.Close();
            con.Dispose();
        }
    }
}