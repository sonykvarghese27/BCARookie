﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class javastart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["x"] == null)
        {
            Response.Write("<script LANGUAGE='JavaScript' >alert('Please login to use all features in this website')</script>");
            Response.Redirect("Login.aspx");
        }
    }
}