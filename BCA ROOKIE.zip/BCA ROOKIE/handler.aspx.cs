﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class handler : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Request.QueryString["ImageID"] != null)
        {
            string strQuery = "select name, type, data from" +
          " semsyllabus where id=@id";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["bcarookieConnectionString"].ConnectionString);
            SqlCommand cmd = new SqlCommand(strQuery);
            cmd.Parameters.Add("@id", SqlDbType.Int).Value
                = Convert.ToInt32(Request.QueryString["ImageID"]);

            SqlDataAdapter sda = new SqlDataAdapter();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            DataTable dt = new DataTable();
            try
            {
                con.Open();
                sda.SelectCommand = cmd;
                sda.Fill(dt);
            }
            catch
            {
                dt = null;
            }
            finally
            {
                con.Close();
                sda.Dispose();
                con.Dispose();
            }
            if (dt != null)
            {
                Byte[] bytes = (Byte[])dt.Rows[0]["data"];
                Response.Buffer = true;
                Response.Charset = "";
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.ContentType = dt.Rows[0]["type"].ToString();
                Response.AddHeader("content-disposition", "attachment;filename="
                    + dt.Rows[0]["name"].ToString());
                Response.BinaryWrite(bytes);
                Response.Flush();
                Response.End();
            }
        }
    }
}