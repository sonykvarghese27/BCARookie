﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Projects : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["x"] == null)
        {
            Response.Write("<script LANGUAGE='JavaScript' >alert('Please login to use all features in this website')</script>");
            Response.Redirect("Login.aspx");
        }

    }
    protected void download(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["bcarookieConnectionString"].ConnectionString);
        LinkButton lnkbtn = sender as LinkButton;
        GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
        int id = Convert.ToInt16(GridView1.DataKeys[gvrow.RowIndex].Value.ToString());
        using (con)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select zip_file, project_title from project where id=@id";
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Response.ContentType = "application/octet-stream";
                    Response.AddHeader("Content-Disposition", "attachment;filename=\"" + dr["project_title"] + ".zip\"");
                    Response.BinaryWrite((byte[])dr["zip_file"]);
                    Response.End();
                }
            }
        }
    }
}